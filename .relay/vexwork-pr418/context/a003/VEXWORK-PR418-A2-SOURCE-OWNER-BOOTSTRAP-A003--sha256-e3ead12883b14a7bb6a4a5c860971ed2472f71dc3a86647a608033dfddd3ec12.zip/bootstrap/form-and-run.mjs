#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const [bootstrapRoot, sdkRoot, ghBin, gitBin, nodeBin] = process.argv.slice(2);
if (!bootstrapRoot || !sdkRoot || !ghBin || !gitBin || !nodeBin) throw new Error('BOOTSTRAP_ARGUMENTS_REQUIRED');

const TARGET_REPO = 'VexGPT/VexWork';
const TARGET_URL = 'https://github.com/VexGPT/VexWork.git';
const TARGET_BRANCH = 'VXG-112126-localization-shared-frame-prod-preview-a003';
const BASE = '5adc12ac7983773a82955c4ef6d59fc386add75f';
const HEAD = 'c2d7edcc8b54baf2f41e3e90b6bc369937b83824';
const TREE = 'fc4e733086caa40219b3b84b6985d9731503a75d';
const COMPANION_BRANCH = 'relay/vexwork-pr418-a2-source-owner-a003';
const RETURN_PREFIX = '.relay/vexwork-pr418/a003/return';
const CHANGED_PATHS = [
  "projects/localization-architecture/inventory/vexlife-prod.main.localization.json",
  "projects/localization-architecture/inventory/vexlife-prod.main.localization.occurrences.csv",
  "projects/localization-architecture/inventory/vexlife-prod.main.localization.strings.csv",
  "projects/vexboard/lens/catalog.json",
  "projects/vexboard/lens/vexlife-prod.main.screen-lens.json",
  "scripts/build-localization-inventory.mjs",
  "src/core/vexboard-localization-vexlife-prod.mjs",
  "src/shared/vexboard-localization-inventory.mjs",
  "test/vexboard-lens-ui.test.mjs",
  "test/vexboard-localization-generated.test.mjs",
  "test/vexboard-localization-inventory.test.mjs",
  "test/vexboard-localization-vexlife-prod.test.mjs",
  "vexboard/lens.html",
  "vexboard/localization-copy.json"
];
const SDK_RUNNER = path.join(sdkRoot, 'lib/vexlocalbridge/templates/RUN-VEX-TASK.command');

function run(command, args, { cwd = undefined, accepted = [0], stdio = 'pipe', env = process.env } = {}) {
  const result = spawnSync(command, args, { cwd, env, encoding: 'utf8', stdio });
  const status = result.status ?? 1;
  if (!accepted.includes(status)) {
    throw new Error('COMMAND_FAILED:' + command + ':' + args.join(' ') + ':exit=' + status + ':' + (result.stderr || result.stdout || ''));
  }
  return result;
}
function sha256File(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}
function walk(root) {
  const out = [];
  if (!fs.existsSync(root)) return out;
  for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
    const p = path.join(root, entry.name);
    if (entry.isDirectory()) out.push(...walk(p));
    else if (entry.isFile()) out.push(p);
  }
  return out;
}

const observedRemote = run(ghBin, ['api', 'repos/' + TARGET_REPO + '/branches/' + TARGET_BRANCH, '--jq', '.commit.sha']).stdout.trim();
if (observedRemote !== HEAD) throw new Error('CANDIDATE_BRANCH_HEAD_MOVED:' + observedRemote + ':' + HEAD);

const carrierFormation = await import(pathToFileURL(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const nativeModule = await import(pathToFileURL(path.join(sdkRoot, 'lib/vexlocalbridge/vexrelay-task-archive.js')).href);
const native = nativeModule.default;
const { formVexRelayTaskArchiveCarrier } = carrierFormation;
const { VEXRELAY_ARCHIVE_PAYLOAD_CLASS, VEXRELAY_ARCHIVE_RUNTIME } = native;

const now = new Date();
const expires = new Date(now.getTime() + 2 * 60 * 60 * 1000);
const repositoryRef = 'primary';
const remainingEffects = ['CHECK_AUTH','READ_REPOSITORY','RUN_LOCAL_COMMAND','CHECK_STATE','QUERY_PROVIDER','FORM_RESULT'];

const seed = {
  schemaVersion: 'vex.relay.task/v2',
  continuity: '[VXG RealForever]',
  taskRef: 'task.vexwork.pr418.localization-a2.source-owner',
  attemptRef: 'attempt.vexwork.pr418.localization-a2.source-owner.a003',
  requestRef: 'request.vexwork.pr418.localization-a2.source-owner.a003',
  correlationRef: 'correlation.vexwork.pr418.localization-a2.source-owner.a003',
  packageRef: 'package.vexwork.pr418.localization-a2.source-owner.a003',
  original: {
    originalIntent: 'Finish the accepted shared-frame Localization experience without reopening architecture.',
    originalGoal: 'Prove the exact PR418 A2 candidate source, generated projections, Lens currentness, and deterministic regression surface.',
    userProtectedIntent: 'Preserve Product-owned localization identity, read-only Lens projection, traceability, and no premature merge authority.',
    sourceRefs: ['github.pull.vexwork.418','github.issue.vexwork.419','github.pull.vexlife-prod.444']
  },
  lane: {
    entryClass: 'FOUNDATION_DELTA',
    scopeMode: 'STAGE_BOUNDED',
    laneRef: 'lane.vexwork.localization-architecture.a2',
    parentRootRef: 'project.vex.localization-architecture',
    workRef: 'work.vex.localization-architecture.localization-inspector',
    claimRef: 'github.pull.vexwork.418',
    returnRouteRef: 'github.issue.vexwork.419',
    ownerRef: 'repo.vexwork',
    rootHubRef: 'project.vex.localization-architecture'
  },
  role: {
    activeRole: 'CODER',
    roleRef: 'role.coder.vexwork.pr418.a2',
    instanceRef: 'instance.vexwork.pr418.a2.source-owner.a003',
    occupancyRef: 'occupancy.vexwork.pr418.a2.source-owner.a003',
    providerBindingRef: 'provider.github.vexwork.pr418',
    threadRef: 'thread.vexwork.pr418.a2.source-owner.a003',
    authorityEnvelopeRef: 'authority-envelope.vexwork.pr418.a2.source-owner.a003'
  },
  capabilities: { platformGitHubRead: 'AVAILABLE', platformGitHubWrite: 'UNAVAILABLE' },
  execution: {
    hostProfile: 'macos-victor',
    executionSurface: 'MAC_ZIP_RUN_COMMAND',
    singleUseNonce: 'nonce-vexwork-pr418-a2-source-owner-a003-112126',
    duplicateAttemptMarker: 'marker.vexwork.pr418.a2.source-owner.a003',
    duplicateProtectionMode: 'OUTER_RELAY_BOUND',
    formedAt: now.toISOString(),
    expiresAtOrNull: expires.toISOString()
  },
  workspace: {
    mode: 'RUN_ROOT',
    projectRef: 'project.vexwork.pr418.source-owner',
    projectPath: 'workspace',
    createRoot: false,
    createProjectPath: true
  },
  repositories: [{
    repositoryRef,
    mode: 'CLONE_IN_WORKSPACE',
    cloneTransport: 'GITHUB_GH',
    githubHostname: 'github.com',
    nameWithOwner: TARGET_REPO,
    localPath: 'repositories/primary',
    remote: 'origin',
    baseBranch: 'main',
    acceptedBase: BASE,
    checkoutRef: HEAD,
    expectedHead: HEAD,
    branch: TARGET_BRANCH
  }],
  authority: {
    authorityRef: 'authority.vexwork.pr418.a2.source-owner',
    authorityMode: 'EXACT_STAGE_EFFECTS',
    grantedEffects: [...remainingEffects],
    conditionalEffects: [],
    consumedEffects: [],
    remainingEffects: [...remainingEffects],
    heldEffects: ['APPROVE_EXACT_HEAD','MARK_READY','ORDINARY_MERGE','POST_MERGE_VERIFY'],
    repositoryMembranes: [{ repositoryRef, allowedPaths: CHANGED_PATHS }],
    allowedExecutables: ['git','gh','node','npm'],
    allowedEnvironment: [],
    remoteObservationOwner: 'LocalRelay',
    allowMutationLoop: false,
    stopConditions: ['STOP_ON_UNKNOWN','STOP_ON_AUTH_BLOCK','STOP_ON_IDENTITY_DRIFT','STOP_ON_TEST_FAILURE']
  },
  source: {
    sourceSetRef: 'source.vexwork.localization-a2.pr418',
    sourceVersionRef: HEAD,
    overlapEvidenceRef: 'github.pull.vexwork.418',
    activeConflictState: 'NONE',
    candidateState: 'EXACT',
    candidateHead: HEAD,
    candidateTree: TREE,
    expectedChangedPaths: CHANGED_PATHS.map((p) => ({ repositoryRef, path: p })),
    intentionallyUnchangedAuthorizedPaths: []
  },
  policy: {
    maxOuterReturnFiles: 10,
    maxSelectedSourceEntries: 10,
    maxSelectedSourceBytes: 5000000,
    maxDiffBytes: 10000000,
    requireRacePreflightBeforeMutation: false,
    requireLocalValidationBeforePublish: false,
    requireInputPackageManifest: false,
    signoffCommit: true,
    draftPullRequest: true
  }
};

const stage = {
  repositoryRef,
  expectedBase: BASE,
  expectedHead: HEAD,
  expectedTree: TREE,
  branch: TARGET_BRANCH,
  proofCommands: [
    {
      command: 'git',
      args: ['merge-base','--is-ancestor',BASE,HEAD],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.vexwork.pr418.fixed-base-ancestor',
      proofClass: 'INVARIANT',
      timeoutMs: 120000
    },
    {
      command: 'npm',
      args: ['run','localization:check'],
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexwork.pr418.localization-currentness',
      proofClass: 'TEST',
      timeoutMs: 300000
    },
    {
      command: 'npm',
      args: ['run','lens:verify'],
      predicateClass: 'SOURCE_OWNER_REPOSITORY',
      predicateRef: 'predicate.vexwork.pr418.lens-currentness',
      proofClass: 'TEST',
      timeoutMs: 300000
    },
    {
      command: 'node',
      args: ['--test','test/vexboard-localization-inventory.test.mjs','test/vexboard-localization-vexlife-prod.test.mjs','test/vexboard-localization-generated.test.mjs','test/vexboard-lens-ui.test.mjs'],
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexwork.pr418.focused-a2-tests',
      proofClass: 'TEST',
      timeoutMs: 300000
    },
    {
      command: 'npm',
      args: ['run','review'],
      predicateClass: 'SOURCE_OWNER_BEHAVIOR',
      predicateRef: 'predicate.vexwork.pr418.repository-review',
      proofClass: 'TEST',
      timeoutMs: 900000
    }
  ],
  maxFiles: 10,
  stateRef: 'state.vexwork.pr418.a2.source-owner.a003',
  currentLifecycleState: 'SOURCE_READY',
  currentGoal: 'Prove the exact lived-accepted A2 Localization candidate.',
  remainingGoals: ['Consume the canonical SourceOwner RETURN.','Run fresh Independent Assurance.','Enter integration only if exact-head evidence remains clear.'],
  onPass: {
    lifecycleState: 'ASSURANCE_PENDING',
    nextFunction: 'F13.RUN_FRESH_ASSURANCE',
    nextOwner: 'Operations',
    whyThisIsNext: 'Exact-head SourceOwner proof is complete; fresh Independent Assurance remains separate.'
  },
  resultFilename: 'RETURN-VEXWORK-PR418-A2-SOURCE-OWNER-A003.zip'
};

const authorityEnvelope = {
  authoritySchemaRef: 'vextreme.effect-transaction/v1',
  semanticAdmissionRef: 'github.issue.vexwork.419',
  transactionRef: 'transaction.vexwork.pr418.a2.source-owner.a003',
  transactionVersion: 1,
  allowedEffectRefs: ['effect.vexrelay.execute'],
  heldEffectRefs: ['effect.independent-assurance','effect.ready-for-integration','effect.merge','effect.post-merge-verification']
};

const outerTaskTemplate = {
  schemaVersion: 'vextreme.vexlocalbridge-task-manifest/v1',
  artifactClass: 'EXECUTABLE_RELAY',
  taskRef: 'task.vexwork.pr418.a2.source-owner.carrier',
  attemptRef: 'attempt.vexwork.pr418.a2.source-owner.carrier.a003',
  packageRef: 'package.vexwork.pr418.a2.source-owner.carrier.a003',
  requestRef: 'request.vexwork.pr418.a2.source-owner.carrier.a003',
  correlationRef: 'correlation.vexwork.pr418.a2.source-owner.carrier.a003',
  taskStorageKey: 'task-vexwork-pr418-a2-source-owner',
  attemptStorageKey: 'attempt-a003',
  requestingRoleRef: 'Operations',
  requestingInstanceRef: 'instance.vexwork.pr418.a2.source-owner.carrier.a003',
  parentOperationsRef: 'github.issue.vexwork.419',
  returnRouteRef: 'github.issue.vexwork.419',
  hostProfileRef: 'macos-victor',
  repositoryExecutionProfileRefOrNull: 'profile.repository.vextreme-sdk.macos-v1',
  repositoryRefOrNull: 'repo.vexwork',
  baseRefOrNull: BASE,
  headRefOrNull: HEAD,
  treeRefOrNull: TREE,
  branchRefOrNull: TARGET_BRANCH,
  claimRefOrNull: 'github.pull.vexwork.418',
  exactPathRefs: CHANGED_PATHS,
  authorityBinding: {
    authoritySchemaRef: 'vextreme.effect-transaction/v1',
    authorityEnvelopePath: 'authority/effect.json',
    authorityEnvelopeSha256: '0'.repeat(64),
    semanticAdmissionRef: 'stale',
    transactionRef: 'stale',
    transactionVersion: 1,
    allowedEffectRefs: ['stale'],
    heldEffectRefs: []
  },
  payload: {
    payloadClass: VEXRELAY_ARCHIVE_PAYLOAD_CLASS,
    payloadRuntime: VEXRELAY_ARCHIVE_RUNTIME,
    payloadPath: 'payload/inner-vexrelay.zip',
    payloadSha256: '0'.repeat(64),
    typedArgv: [],
    immutableInputs: [{ path: 'inputs/vexrelay-binding.json', sha256: '0'.repeat(64) }]
  },
  executionStateAtFormation: 'TASK_PREPARED',
  singleUseNonce: 'nonce-vexwork-pr418-a2-source-owner-carrier-a003',
  stopConditions: ['stop.on.identity.drift','stop.on.proof.failure','stop.on.authority.block'],
  archiveDigestBinding: 'FILENAME_SHA256'
};

const outputDirectory = path.join(os.homedir(), 'Downloads');
const formed = await formVexRelayTaskArchiveCarrier({
  recipe: 'ExactHeadSourceOwnerProof',
  seed,
  stage,
  outerTaskTemplate,
  authorityEnvelope,
  outputDirectory,
  outputStem: 'VEXWORK-PR418-A2-SOURCE-OWNER-A003',
  ttlMs: 60 * 60 * 1000
});

process.stdout.write('Relay task formed: ' + formed.outer.finalZip + '\n');
process.stdout.write('Relay task sha256: ' + formed.outer.digest + '\n');

const launch = spawnSync('/bin/bash', [SDK_RUNNER, formed.outer.finalZip], {
  stdio: 'inherit',
  env: { ...process.env, VEX_EXPECTED_PACKAGE_SHA256: formed.outer.digest }
});
const launchStatus = launch.status ?? 1;
const capsuleRoot = formed.outer.finalZip.replace(/\.zip$/i, '') + '-run-' + formed.outer.digest.slice(0, 16);
const resultRoot = path.join(capsuleRoot, 'results');
const returnCandidates = walk(resultRoot).filter((p) => /\.zip$/i.test(p) && path.basename(p).startsWith('RETURN-'));
if (returnCandidates.length !== 1) throw new Error('CANONICAL_OUTER_RETURN_COUNT:' + returnCandidates.length);
const outerReturn = returnCandidates[0];
const outerSha256 = sha256File(outerReturn);

const extracted = fs.mkdtempSync(path.join(os.tmpdir(), 'vexwork-pr418-outer-return-'));
try {
  run('/usr/bin/ditto', ['-x','-k',outerReturn,extracted]);
  const innerReturns = walk(extracted).filter((p) => /retained\/inner-vexrelay\/.*\.zip$/i.test(p));
  if (innerReturns.length !== 1) throw new Error('RETAINED_INNER_RETURN_COUNT:' + innerReturns.length);
  const innerReturn = innerReturns[0];
  const innerSha256 = sha256File(innerReturn);

  const carrierRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'vexwork-pr418-carrier-'));
  try {
    run(ghBin, ['repo','clone',TARGET_REPO,carrierRoot,'--','--branch',COMPANION_BRANCH,'--single-branch']);
    const branch = run(gitBin, ['-C',carrierRoot,'rev-parse','--abbrev-ref','HEAD']).stdout.trim();
    if (branch !== COMPANION_BRANCH) throw new Error('COMPANION_BRANCH_MISMATCH:' + branch);
    const returnDir = path.join(carrierRoot, RETURN_PREFIX);
    fs.mkdirSync(returnDir, { recursive: true });
    const destination = path.join(returnDir, path.basename(outerReturn));
    if (fs.existsSync(destination)) {
      if (sha256File(destination) !== outerSha256) throw new Error('EXISTING_RETURN_DIGEST_CONFLICT');
    } else {
      fs.copyFileSync(outerReturn, destination);
    }
    if (sha256File(destination) !== outerSha256) throw new Error('PUBLISHED_RETURN_COPY_MISMATCH');

    const receipt = {
      schemaVersion: 'vexwork.relay-return-receipt/v1',
      continuity: '[VXG RealForever]',
      carrierIssue: 'github.issue.vexwork.419',
      productPullRequest: 'github.pull.vexwork.418',
      candidate: { base: BASE, head: HEAD, tree: TREE, branch: TARGET_BRANCH },
      sourceOwnerTask: {
        recipe: 'ExactHeadSourceOwnerProof',
        stageGate: 'EXACT_HEAD_SOURCE_OWNER_PROOF',
        outerTaskZipSha256: formed.outer.digest,
        outerReturnSha256: outerSha256,
        innerReturnSha256: innerSha256,
        runnerExitStatus: launchStatus
      },
      custody: { carrierBranch: COMPANION_BRANCH, returnPath: RETURN_PREFIX + '/' + path.basename(outerReturn) },
      observedAt: new Date().toISOString()
    };
    const receiptPath = path.join(returnDir, 'receipt.json');
    fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');

    run(gitBin, ['-C',carrierRoot,'config','user.name','Vex Relay']);
    run(gitBin, ['-C',carrierRoot,'config','user.email','vex-relay@users.noreply.github.com']);
    run(gitBin, ['-C',carrierRoot,'add','--',path.relative(carrierRoot,destination),path.relative(carrierRoot,receiptPath)]);
    const status = run(gitBin, ['-C',carrierRoot,'status','--porcelain=v1']).stdout.trim();
    if (status) {
      run(gitBin, ['-C',carrierRoot,'commit','-m','[Relay][PR418][A2] Preserve A003 canonical SourceOwner RETURN']);
      run(gitBin, ['-C',carrierRoot,'push','origin','HEAD:refs/heads/' + COMPANION_BRANCH]);
    }

    process.stdout.write('Canonical outer RETURN: ' + destination + '\n');
    process.stdout.write('Outer RETURN sha256: ' + outerSha256 + '\n');
    process.stdout.write('Retained inner RETURN sha256: ' + innerSha256 + '\n');
  } finally {
    fs.rmSync(carrierRoot, { recursive: true, force: true });
  }
} finally {
  fs.rmSync(extracted, { recursive: true, force: true });
}

process.exitCode = launchStatus;
