#!/bin/bash
set -euo pipefail
ROOT="${1:?bootstrap root required}"
SDK_REPO="vgong24/Vextreme-SDK"
SDK_HEAD="6f8f6f50467f5df5a542713f7dc25b82db4ac8fa"
SDK_TREE="96795640b01f1969da980f52d5a8ec136a8c44aa"
CONTRACT_BLOB="b53cbac01c2deeb45fad5c32ce98e0796c04126f"

GH_BIN=""
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh; do
  if [ -x "$candidate" ]; then GH_BIN="$candidate"; break; fi
done
[ -n "$GH_BIN" ] || { printf '%s\n' 'Relay bootstrap: qualified GitHub CLI not found.' >&2; exit 20; }
GIT_BIN="/usr/bin/git"
[ -x "$GIT_BIN" ] || { printf '%s\n' 'Relay bootstrap: /usr/bin/git missing.' >&2; exit 21; }
NODE_BIN=""
for candidate in /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do
  if [ -x "$candidate" ]; then NODE_BIN="$candidate"; break; fi
done
[ -n "$NODE_BIN" ] || { printf '%s\n' 'Relay bootstrap: qualified Node not found.' >&2; exit 22; }

"$GH_BIN" auth status --hostname github.com >/dev/null
TMP="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/VEXWORK-PR418-A001.XXXXXX")"
trap '/bin/rm -rf "$TMP"' EXIT HUP INT TERM
"$GH_BIN" repo clone "$SDK_REPO" "$TMP/sdk" -- --no-checkout
"$GIT_BIN" -C "$TMP/sdk" checkout --detach "$SDK_HEAD" >/dev/null
[ "$("$GIT_BIN" -C "$TMP/sdk" rev-parse HEAD)" = "$SDK_HEAD" ] || { printf '%s\n' 'Relay bootstrap: SDK head mismatch.' >&2; exit 23; }
[ "$("$GIT_BIN" -C "$TMP/sdk" rev-parse "HEAD^{tree}")" = "$SDK_TREE" ] || { printf '%s\n' 'Relay bootstrap: SDK tree mismatch.' >&2; exit 24; }
[ "$("$GIT_BIN" -C "$TMP/sdk" rev-parse "HEAD:docs/private-continuity/vexrelay/current-contract.json")" = "$CONTRACT_BLOB" ] || { printf '%s\n' 'Relay bootstrap: current-contract blob mismatch.' >&2; exit 25; }
[ -z "$("$GIT_BIN" -C "$TMP/sdk" status --porcelain=v1 -uall)" ] || { printf '%s\n' 'Relay bootstrap: acquired SDK source is dirty.' >&2; exit 26; }
"$NODE_BIN" -e 'const fs=require("node:fs");const x=JSON.parse(fs.readFileSync(process.argv[1],"utf8"));if(x.contractRef!=="source.vexrelay.current-contract/v1")process.exit(27);' "$TMP/sdk/docs/private-continuity/vexrelay/current-contract.json"
exec "$NODE_BIN" "$ROOT/bootstrap/form-and-run.mjs" "$ROOT" "$TMP/sdk" "$GH_BIN" "$GIT_BIN" "$NODE_BIN"
