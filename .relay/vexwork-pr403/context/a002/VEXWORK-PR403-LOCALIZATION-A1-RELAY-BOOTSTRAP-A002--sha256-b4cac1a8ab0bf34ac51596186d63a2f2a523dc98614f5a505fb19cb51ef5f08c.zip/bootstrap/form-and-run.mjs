#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const SDK_ROOT=path.resolve(process.argv[2]||'');
if(!SDK_ROOT) throw new Error('SDK_ROOT_REQUIRED');
const DOWNLOADS=path.join(os.homedir(),'Downloads');
const BASE='9b48268876ebba4b1ad91f753d9c497916d9bb74';
const HEAD='544d18d9f85a237f120d0cf5dbb9a2ffbfd06af0';
const TREE='8652a693cf3d36d799183c4f4b7bb6681f7b7c1f';
const BRANCH='VXG-112126-localization-android-inventory-a001';
const CARRIER_BRANCH='relay/vexwork-pr403-source-owner-a001';
const CARRIER_PREFIX='.relay/vexwork-pr403/a002';
const EXPECTED_PATHS=[
'package.json',
'projects/localization-architecture/LOCALIZATION-INVENTORY.md',
'projects/localization-architecture/inventory/vexlife-android.main.localization.json',
'projects/localization-architecture/inventory/vexlife-android.main.localization.occurrences.csv',
'projects/localization-architecture/inventory/vexlife-android.main.localization.strings.csv',
'public/workspace.json',
'scripts/build-localization-inventory.mjs',
'src/core/vexboard-localization-android.mjs',
'src/shared/vexboard-localization-inventory.mjs',
'test/vexboard-localization-android.test.mjs',
'test/vexboard-localization-generated.test.mjs',
'test/vexboard-localization-inventory.test.mjs',
'workgraphs/public.json',
'workgraphs/segments/localization-architecture.json'];


function run(command,args,{cwd=null,capture=false,env={}}={}){
  const result=spawnSync(command,args,{encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit',env:{...process.env,...env},cwd:cwd||undefined});
  if(result.status!==0){const error=new Error(`COMMAND_FAILED:${command}:${args.join(' ')}:${result.status}`);error.stdout=result.stdout||'';error.stderr=result.stderr||'';throw error;}
  return result.stdout||'';
}
function shasum(file){return run('/usr/bin/shasum',['-a','256',file],{capture:true}).trim().split(/\s+/)[0];}

const now=new Date();
const expires=new Date(now.getTime()+90*60*1000);
const markerDir=path.join(os.homedir(),'Library','Application Support','Vextreme','VexLocalBridge','state','bootstrap-formations');
fs.mkdirSync(markerDir,{recursive:true});
const marker=path.join(markerDir,'vexwork-pr403-a1-source-owner-a002.json');
try{fs.writeFileSync(marker,JSON.stringify({state:'FORMING',taskRef:'task.vexwork.pr403.a1.source-owner.a002',attemptRef:'attempt.vexwork.pr403.source-owner.a002',head:HEAD,tree:TREE,formedAt:now.toISOString()},null,2)+'\n',{flag:'wx'});}catch(error){if(error?.code==='EEXIST')throw new Error(`A002_ALREADY_FORMED_FAIL_CLOSED:${marker}`);throw error;}

const { formVexRelayTaskArchiveCarrier }=await import(pathToFileURL(path.join(SDK_ROOT,'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const nativeModule=await import(pathToFileURL(path.join(SDK_ROOT,'lib/vexlocalbridge/vexrelay-task-archive.js')).href);
const native=nativeModule.default;
const remainingEffects=['CHECK_AUTH','READ_REPOSITORY','CHECK_STATE','QUERY_PROVIDER','RUN_LOCAL_COMMAND','FORM_RESULT'];
const seed={
 schemaVersion:'vex.relay.task/v2',continuity:'[VXG RealForever]',
 taskRef:'task.vexwork.pr403.a1.source-owner.a002',attemptRef:'attempt.vexwork.pr403.source-owner.a002',requestRef:'request.vexwork.pr403.source-owner.a002',correlationRef:'correlation.vexwork.pr403.source-owner.a002',packageRef:'package.vexwork.pr403.source-owner.a002',
 original:{originalIntent:'Build the first source-faithful Android Localization Inventory before any localization UI: exact source strings plus Screen Lens occurrences, reverse where-used, deterministic JSON/CSV views.',originalGoal:'Prove exact PR403 A1: full Android source catalog + mapped occurrences + source-backed currentness + generated views + Workgraph/workspace projection.',userProtectedIntent:'Preserve Product source ownership and Screen Lens identity; no source mutation, no semantic duplicate merging, no locale UI, no toolbar replacement.',sourceRefs:['github.issue.vexwork.404','github.pull.vexwork.403','project.vex.localization-architecture','projects/localization-architecture/LOCALIZATION-INVENTORY.md']},
 lane:{entryClass:'FOUNDATION_DELTA',scopeMode:'STAGE_BOUNDED',laneRef:'lane.vexwork.localization-architecture',parentRootRef:'github.issue.vexwork.404',workRef:'work.vex.localization-architecture.android-inventory',claimRef:'claim.vexwork.localization-architecture.pr403.a1.source-owner',returnRouteRef:'github.issue.vexwork.404',ownerRef:'owner.vexwork.localization-architecture',rootHubRef:'github.issue.vexwork.404'},
 role:{activeRole:'CODER',roleRef:'role.coder.vexwork.pr403.a002',instanceRef:'instance.coder.vexwork.pr403.a002',occupancyRef:'occupancy.vexwork.pr403.a002',providerBindingRef:'provider.github.vexwork.pr403',threadRef:'github.issue.vexwork.404',authorityEnvelopeRef:'authority-envelope.vexwork.pr403.source-owner.a002'},
 capabilities:{platformGitHubRead:'AVAILABLE',platformGitHubWrite:'AVAILABLE'},
 execution:{hostProfile:'macos-victor',executionSurface:'MAC_ZIP_RUN_COMMAND',singleUseNonce:'nonce-'+crypto.randomBytes(18).toString('hex'),duplicateAttemptMarker:'marker.vexwork.pr403.source-owner.a002',duplicateProtectionMode:'OUTER_RELAY_BOUND',formedAt:now.toISOString(),expiresAtOrNull:expires.toISOString()},
 workspace:{mode:'RUN_ROOT',projectRef:'project.vex.localization-architecture.proof',projectPath:'workspace',createRoot:false,createProjectPath:true},
 repositories:[{repositoryRef:'primary',mode:'CLONE_IN_WORKSPACE',nameWithOwner:'VexGPT/VexWork',localPath:'repo',remote:'origin',baseBranch:'main',acceptedBase:BASE,checkoutRef:HEAD,expectedHead:HEAD,branch:BRANCH,expectedRemoteUrl:null,cloneTransport:'GITHUB_GH',githubHostname:'github.com'}],
 authority:{authorityRef:'authority.vexwork.pr403.source-owner.a002',authorityMode:'EXACT_STAGE_EFFECTS',grantedEffects:[...remainingEffects],conditionalEffects:[],consumedEffects:[],remainingEffects:[...remainingEffects],heldEffects:['WRITE_SOURCE','CREATE_BRANCH','CREATE_COMMIT','PUSH_BRANCH','CREATE_PULL_REQUEST','UPDATE_COORDINATION_METADATA','APPROVE_EXACT_HEAD','MARK_READY','ORDINARY_MERGE'],repositoryMembranes:[{repositoryRef:'primary',allowedPaths:EXPECTED_PATHS}],allowedExecutables:['node','npm','git','gh'],allowedEnvironment:[],remoteObservationOwner:'LocalRelay',allowMutationLoop:false,stopConditions:['STOP_ON_UNKNOWN','STOP_ON_PATH_ESCAPE','STOP_ON_AUTH_BLOCK','STOP_ON_TEST_FAILURE']},
 source:{sourceSetRef:'source-set.vexwork.pr403.a1',sourceVersionRef:'source-version.vexwork.pr403.544d18d9',overlapEvidenceRef:'overlap.vexwork.pr403.a1.none',activeConflictState:'NONE',candidateState:'EXACT',candidateHead:HEAD,candidateTree:TREE,expectedChangedPaths:EXPECTED_PATHS.map(path=>({repositoryRef:'primary',path})),intentionallyUnchangedAuthorizedPaths:[]},
 policy:{maxOuterReturnFiles:10,maxSelectedSourceEntries:10,maxSelectedSourceBytes:500000,maxDiffBytes:5000000,requireRacePreflightBeforeMutation:false,requireLocalValidationBeforePublish:false,requireInputPackageManifest:true,signoffCommit:true,draftPullRequest:true}
};
const stage={repositoryRef:'primary',expectedBase:BASE,expectedHead:HEAD,expectedTree:TREE,branch:BRANCH,pullRequestNumber:403,maxFiles:10,proofCommands:[
 {command:'npm',args:['run','localization:check'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_BEHAVIOR',predicateRef:'predicate.vexwork.pr403.localization-source-current',timeoutMs:900000},
 {command:'node',args:['--test','test/vexboard-localization-inventory.test.mjs','test/vexboard-localization-android.test.mjs','test/vexboard-localization-generated.test.mjs'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_BEHAVIOR',predicateRef:'predicate.vexwork.pr403.localization-focused-regressions',timeoutMs:600000},
 {command:'npm',args:['run','lens:verify'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexwork.pr403.screen-lens-current',timeoutMs:600000},
 {command:'npm',args:['run','workgraph:check'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexwork.pr403.workgraph-current',timeoutMs:600000},
 {command:'npm',args:['run','workspace:check'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexwork.pr403.workspace-current',timeoutMs:600000},
 {command:'npm',args:['run','review'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_BEHAVIOR',predicateRef:'predicate.vexwork.pr403.full-review-floor',timeoutMs:1800000}
 ],stateRef:'state.vexwork.pr403.a1.source-ready.a002',currentLifecycleState:'SOURCE_READY',currentGoal:'Prove exact PR403 Android Localization Inventory A1 only.',remainingGoals:['Translated locale variants remain separate.','Localization Inspector and toolbar placement remain separate.','Change Set and semantic duplicate convergence remain separate.','Product source mutation remains held.','Fresh Independent Assurance remains separate.','READY / merge remain separate.'],onPass:{lifecycleState:'ASSURANCE_PENDING',nextFunction:'F13.RUN_FRESH_ASSURANCE',nextOwner:'Operations',whyThisIsNext:'Exact-head Android Localization Inventory source-owner proof is complete; fresh Independent Assurance remains unconsumed.'},resultFilename:'RETURN-VEXWORK-PR403-SOURCE-OWNER-A002.zip'};
const authorityEnvelope={authoritySchemaRef:'vextreme.effect-transaction/v1',semanticAdmissionRef:'github.issue.vexwork.404',transactionRef:'transaction.vexwork.pr403.source-owner.a002',transactionVersion:1,allowedEffectRefs:['effect.vexrelay.execute'],heldEffectRefs:['effect.vexwork.approval','effect.vexwork.ready','effect.vexwork.merge']};
const outerTaskTemplate={schemaVersion:'vextreme.vexlocalbridge-task-manifest/v1',artifactClass:'EXECUTABLE_RELAY',taskRef:'task.vexwork.pr403.a1.vexrelay-carrier.a002',attemptRef:'attempt.vexwork.pr403.vexrelay-carrier.a002',packageRef:'package.vexwork.pr403.vexrelay-carrier.a002',requestRef:'request.vexwork.pr403.vexrelay-carrier.a002',correlationRef:'correlation.vexwork.pr403.vexrelay-carrier.a002',taskStorageKey:'vexwork-pr403-a1-source-owner',attemptStorageKey:'a004',requestingRoleRef:'Coder[VEXWORK]',requestingInstanceRef:'instance.vexwork.pr403.source-owner.a002',parentOperationsRef:'github.issue.vexwork.404',returnRouteRef:'github.issue.vexwork.404',hostProfileRef:'macos-victor',repositoryExecutionProfileRefOrNull:'profile.repository.vextreme-sdk.macos-v1',repositoryRefOrNull:'VexGPT/VexWork',baseRefOrNull:BASE,headRefOrNull:HEAD,treeRefOrNull:TREE,branchRefOrNull:BRANCH,claimRefOrNull:'claim.vexwork.localization-architecture.pr403.a1.source-owner',exactPathRefs:EXPECTED_PATHS,authorityBinding:{authoritySchemaRef:'vextreme.effect-transaction/v1',authorityEnvelopePath:'authority/effect.json',authorityEnvelopeSha256:'0'.repeat(64),semanticAdmissionRef:'stale',transactionRef:'stale',transactionVersion:1,allowedEffectRefs:['stale'],heldEffectRefs:[]},payload:{payloadClass:native.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,payloadRuntime:native.VEXRELAY_ARCHIVE_RUNTIME,payloadPath:'payload/inner-vexrelay.zip',payloadSha256:'0'.repeat(64),typedArgv:[],immutableInputs:[{path:'inputs/vexrelay-binding.json',sha256:'0'.repeat(64)}]},executionStateAtFormation:'TASK_PREPARED',singleUseNonce:'outer-nonce-'+crypto.randomBytes(18).toString('hex'),stopConditions:['stop.on.identity.drift','stop.on.source-owner.failure','stop.on.unknown'],archiveDigestBinding:'FILENAME_SHA256'};

const formed=await formVexRelayTaskArchiveCarrier({recipe:'ExactHeadSourceOwnerProof',seed,stage,outerTaskTemplate,authorityEnvelope,outputDirectory:DOWNLOADS,outputStem:'VEXWORK-PR403-LOCALIZATION-A1-SOURCE-PROOF-A002',ttlMs:90*60*1000});
const outerZip=formed.outer.finalZip;
const runner=path.join(SDK_ROOT,'lib/vexlocalbridge/templates/RUN-VEX-TASK.command');
const child=spawnSync('/bin/bash',[runner,outerZip],{encoding:'utf8',env:{...process.env,VEXLOCALBRIDGE_AUTHORIZED_EFFECT_REFS_JSON:JSON.stringify(['effect.vexrelay.execute'])}});
process.stdout.write(child.stdout||'');process.stderr.write(child.stderr||'');
if(child.status!==0)throw new Error(`VEXLOCALBRIDGE_RUN_FAILED:${child.status}`);
const matches=(child.stdout||'').match(/"resultZip"\s*:\s*"([^"]+)"/g);
if(!matches?.length)throw new Error('OUTER_RETURN_PATH_NOT_FOUND');
const returnPath=JSON.parse('{'+matches[matches.length-1]+'}').resultZip;
if(!fs.existsSync(returnPath))throw new Error(`OUTER_RETURN_MISSING:${returnPath}`);
const returnSha=shasum(returnPath);

const carrierRoot=fs.mkdtempSync(path.join(os.tmpdir(),'vexwork-pr403-carrier-'));
run('gh',['repo','clone','VexGPT/VexWork',carrierRoot,'--','--branch',CARRIER_BRANCH,'--single-branch']);
const bootstrapManifest=path.join(carrierRoot,CARRIER_PREFIX,'BOOTSTRAP-MANIFEST.json');
if(!fs.existsSync(bootstrapManifest))throw new Error('CARRIER_BOOTSTRAP_MANIFEST_MISSING');
const bm=JSON.parse(fs.readFileSync(bootstrapManifest,'utf8'));
if(bm.candidateHead!==HEAD||bm.candidateTree!==TREE)throw new Error('CARRIER_CANDIDATE_BINDING_DRIFT');
const returnDir=path.join(carrierRoot,CARRIER_PREFIX,'return');fs.mkdirSync(returnDir,{recursive:true});
const target=path.join(returnDir,path.basename(returnPath));
if(fs.existsSync(target))throw new Error('A002_RETURN_ALREADY_PUBLISHED_FAIL_CLOSED');
fs.copyFileSync(returnPath,target);
if(shasum(target)!==returnSha)throw new Error('RETURN_COPY_DIGEST_MISMATCH');
const receipt={schemaVersion:'vexwork.vexrelay-github-custody-receipt/v1',continuity:'[VXG RealForever]',carrierIssue:'github.issue.vexwork.404',pullRequest:'github.pull.vexwork.403',candidateBase:BASE,candidateHead:HEAD,candidateTree:TREE,outerReturnFilename:path.basename(target),outerReturnSha256:returnSha,canonicalReturnBytesChanged:false,transportMeaning:'GitHub custody only; VexRelay remains canonical result owner.',publishedAt:new Date().toISOString()};
fs.writeFileSync(path.join(returnDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
run('git',['config','user.name','VexRelay GitHub Carrier'],{cwd:carrierRoot});
run('git',['config','user.email','vexrelay-carrier@vextreme.invalid'],{cwd:carrierRoot});
run('git',['add',path.relative(carrierRoot,target),path.relative(carrierRoot,path.join(returnDir,'receipt.json'))],{cwd:carrierRoot});
run('git',['commit','-m','[VexRelay][PR403][Localization A1] Publish canonical A002 RETURN custody'],{cwd:carrierRoot});
run('git',['push','origin',`HEAD:${CARRIER_BRANCH}`],{cwd:carrierRoot});
const carrierCommit=run('git',['rev-parse','HEAD'],{cwd:carrierRoot,capture:true}).trim();
console.log('VEXWORK_PR403_RELAY_DISPOSITION=PASS_TRANSPORT_COMPLETE');
console.log(`VEXWORK_PR403_CANONICAL_RETURN_SHA256=${returnSha}`);
console.log(`VEXWORK_PR403_GITHUB_CARRIER_COMMIT=${carrierCommit}`);
console.log(`VEXWORK_PR403_GITHUB_RETURN_PATH=${CARRIER_PREFIX}/return/${path.basename(target)}`);
