#!/bin/bash
set -euo pipefail
ROOT="${1:-}"
if [ -z "$ROOT" ] || [ ! -d "$ROOT" ]; then
  printf '%s\n' 'Bootstrap root is required.' >&2
  exit 2
fi
GH=""
for candidate in /opt/homebrew/bin/gh /usr/local/bin/gh; do [ -x "$candidate" ] && GH="$candidate" && break; done
GIT=/usr/bin/git
NODE=""
for candidate in /opt/homebrew/bin/node /usr/local/bin/node /usr/bin/node; do [ -x "$candidate" ] && NODE="$candidate" && break; done
if [ -z "$GH" ] || [ ! -x "$GIT" ] || [ -z "$NODE" ]; then
  printf '%s\n' 'Qualified gh/git/node executables are required.' >&2
  exit 127
fi
"$GH" auth status -h github.com >/dev/null
TMP="$(/usr/bin/mktemp -d "${TMPDIR:-/tmp}/VEXBOARD-PR393-RELAY.XXXXXX")"
trap '/bin/rm -rf "$TMP"' EXIT HUP INT TERM
SDK="$TMP/sdk"
"$GH" repo clone vgong24/Vextreme-SDK "$SDK" -- --filter=blob:none --no-checkout
"$GIT" -C "$SDK" checkout --detach "6f8f6f50467f5df5a542713f7dc25b82db4ac8fa"
OBS_HEAD="$("$GIT" -C "$SDK" rev-parse HEAD)"
OBS_TREE="$("$GIT" -C "$SDK" rev-parse 'HEAD^{tree}')"
[ "$OBS_HEAD" = "6f8f6f50467f5df5a542713f7dc25b82db4ac8fa" ] || { printf 'SDK head mismatch: %s\n' "$OBS_HEAD" >&2; exit 10; }
[ "$OBS_TREE" = "96795640b01f1969da980f52d5a8ec136a8c44aa" ] || { printf 'SDK tree mismatch: %s\n' "$OBS_TREE" >&2; exit 11; }
OBS_BLOB="$("$GIT" -C "$SDK" rev-parse 'HEAD:docs/private-continuity/vexrelay/current-contract.json')"
[ "$OBS_BLOB" = "b53cbac01c2deeb45fad5c32ce98e0796c04126f" ] || { printf 'Relay contract blob mismatch: %s\n' "$OBS_BLOB" >&2; exit 12; }
"$NODE" -e 'const fs=require("fs");const p=process.argv[1];const v=JSON.parse(fs.readFileSync(p,"utf8"));if(v.contractRef!=="source.vexrelay.current-contract/v1")process.exit(13)' "$SDK/docs/private-continuity/vexrelay/current-contract.json"
"$NODE" "$ROOT/bootstrap/form-and-run.mjs" "$SDK"
