#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const SDK_ROOT=path.resolve(process.argv[2]||'');
if(!SDK_ROOT) throw new Error('SDK_ROOT_REQUIRED');
const DOWNLOADS=path.join(os.homedir(),'Downloads');
const BASE='de717e8fcf280b1c1253eef3ca4bdbcf48c30427';
const HEAD='c54c02a4e9ee81e8b8bca4ccc7347c64207bcde7';
const TREE='c309ed8ae6c89e6d985a69d3e8ee516c2354d19c';
const BRANCH='VXG-112026-vexboard-candidate-subjects-and-selection-behavior-a001';
const CARRIER_BRANCH='relay/vexboard-pr393-source-owner-a001';
const CARRIER_PREFIX='.relay/vexboard-pr393/a001';
const EXPECTED_PATHS=[
'projects/vexboard/lens/catalog.json',
'projects/vexboard/lens/vexstream-music.main.screen-lens.json',
'scripts/build-screen-lens.mjs',
'src/shared/vexboard-lens-catalog.mjs',
'src/shared/vexboard-screen-lens-realization.mjs',
'src/shared/vexboard-screen-lens-source-expressions.mjs',
'test/vexboard-lens-catalog.test.mjs',
'test/vexboard-lens-ui.test.mjs',
'test/vexboard-screen-lens-generated.test.mjs',
'test/vexboard-screen-lens-realization.test.mjs',
'test/vexboard-screen-lens-source-expressions.test.mjs',
'vexboard/lens.html'];
const FOCUSED=[
'test/vexboard-lens-catalog.test.mjs',
'test/vexboard-screen-lens-realization.test.mjs',
'test/vexboard-screen-lens-source-expressions.test.mjs',
'test/vexboard-lens-ui.test.mjs'];
const VEXBOARD_TESTS=[
'test/vexboard-lens-catalog.test.mjs',
'test/vexboard-lens-commit-source.test.mjs',
'test/vexboard-lens-layout.test.mjs',
'test/vexboard-lens-ui.test.mjs',
'test/vexboard-screen-design.test.mjs',
'test/vexboard-screen-lens-android-adapter.test.mjs',
'test/vexboard-screen-lens-behavior-port-adapter.test.mjs',
'test/vexboard-screen-lens-conformance.test.mjs',
'test/vexboard-screen-lens-events-expression-source.test.mjs',
'test/vexboard-screen-lens-expressions.test.mjs',
'test/vexboard-screen-lens-frames.test.mjs',
'test/vexboard-screen-lens-generated.test.mjs',
'test/vexboard-screen-lens-query.test.mjs',
'test/vexboard-screen-lens-realization.test.mjs',
'test/vexboard-screen-lens-revision.test.mjs',
'test/vexboard-screen-lens-source-expressions.test.mjs',
'test/vexboard-screen-lens-vexstream-expression-source.test.mjs',
'test/vexboard-screen-lens-vexstream-reference.test.mjs',
'test/vexboard-screen-lens.test.mjs'];

function run(command,args,{cwd=null,capture=false,env={}}={}){
  const result=spawnSync(command,args,{encoding:'utf8',stdio:capture?['ignore','pipe','pipe']:'inherit',env:{...process.env,...env},cwd:cwd||undefined});
  if(result.status!==0){const error=new Error(`COMMAND_FAILED:${command}:${args.join(' ')}:${result.status}`);error.stdout=result.stdout||'';error.stderr=result.stderr||'';throw error;}
  return result.stdout||'';
}
function shasum(file){return run('/usr/bin/shasum',['-a','256',file],{capture:true}).trim().split(/\s+/)[0];}

const now=new Date();
const expires=new Date(now.getTime()+90*60*1000);
const markerDir=path.join(os.homedir(),'Library','Application Support','Vextreme','VexLocalBridge','state','bootstrap-formations');
fs.mkdirSync(markerDir,{recursive:true});
const marker=path.join(markerDir,'vexboard-pr393-source-owner-a001.json');
try{fs.writeFileSync(marker,JSON.stringify({state:'FORMING',taskRef:'task.vexboard.pr393.source-owner',attemptRef:'attempt.vexboard.pr393.source-owner.a001',head:HEAD,tree:TREE,formedAt:now.toISOString()},null,2)+'\n',{flag:'wx'});}catch(error){if(error?.code==='EEXIST')throw new Error(`A001_ALREADY_FORMED_FAIL_CLOSED:${marker}`);throw error;}

const { formVexRelayTaskArchiveCarrier }=await import(pathToFileURL(path.join(SDK_ROOT,'lib/vexlocalbridge/vexrelay-task-archive-carrier-formation.mjs')).href);
const nativeModule=await import(pathToFileURL(path.join(SDK_ROOT,'lib/vexlocalbridge/vexrelay-task-archive.js')).href);
const native=nativeModule.default;
const remainingEffects=['CHECK_AUTH','READ_REPOSITORY','CHECK_STATE','QUERY_PROVIDER','RUN_LOCAL_COMMAND','FORM_RESULT'];
const seed={
 schemaVersion:'vex.relay.task/v2',continuity:'[VXG RealForever]',
 taskRef:'task.vexboard.pr393.source-owner',attemptRef:'attempt.vexboard.pr393.source-owner.a001',requestRef:'request.vexboard.pr393.source-owner.a001',correlationRef:'correlation.vexboard.pr393.source-owner.a001',packageRef:'package.vexboard.pr393.source-owner.a001',
 original:{originalIntent:'Make the Screen Lens frame trustworthy across projection subjects before combinable localization is added.',originalGoal:'Prove the exact PR393 candidate: candidate subject lifecycle plus source-owned selection behavior on one shared renderer.',userProtectedIntent:'One renderer and one projection grammar; no synthetic Stable, no Product-specific behavior fork, no lifecycle effect in this proof.',sourceRefs:['github.issue.vexwork.394','github.pull.vexwork.393','github.pull.vexstream-music.33']},
 lane:{entryClass:'FOUNDATION_DELTA',scopeMode:'STAGE_BOUNDED',laneRef:'lane.vexboard.frame-consistency',parentRootRef:'github.issue.vexwork.394',workRef:'work.vexboard.frame-consistency.pr393',claimRef:'claim.vexboard.frame-consistency.pr393.source-owner',returnRouteRef:'github.issue.vexwork.394',ownerRef:'owner.vexboard.screen-lens',rootHubRef:'github.issue.vexwork.394'},
 role:{activeRole:'CODER',roleRef:'role.coder.vexboard.pr393',instanceRef:'instance.coder.vexboard.pr393.a001',occupancyRef:'occupancy.vexboard.pr393.a001',providerBindingRef:'provider.github.vexwork.pr393',threadRef:'github.issue.vexwork.394',authorityEnvelopeRef:'authority-envelope.vexboard.pr393.source-owner.a001'},
 capabilities:{platformGitHubRead:'AVAILABLE',platformGitHubWrite:'AVAILABLE'},
 execution:{hostProfile:'macos-victor',executionSurface:'MAC_ZIP_RUN_COMMAND',singleUseNonce:'nonce-'+crypto.randomBytes(18).toString('hex'),duplicateAttemptMarker:'marker.vexboard.pr393.source-owner.a001',duplicateProtectionMode:'OUTER_RELAY_BOUND',formedAt:now.toISOString(),expiresAtOrNull:expires.toISOString()},
 workspace:{mode:'RUN_ROOT',projectRef:'project.vexboard.frame-consistency-proof',projectPath:'workspace',createRoot:false,createProjectPath:true},
 repositories:[{repositoryRef:'primary',mode:'CLONE_IN_WORKSPACE',nameWithOwner:'VexGPT/VexWork',localPath:'repo',remote:'origin',baseBranch:'main',acceptedBase:BASE,checkoutRef:HEAD,expectedHead:HEAD,branch:BRANCH,expectedRemoteUrl:null,cloneTransport:'GITHUB_GH',githubHostname:'github.com'}],
 authority:{authorityRef:'authority.vexboard.pr393.source-owner.a001',authorityMode:'EXACT_STAGE_EFFECTS',grantedEffects:[...remainingEffects],conditionalEffects:[],consumedEffects:[],remainingEffects:[...remainingEffects],heldEffects:['WRITE_SOURCE','CREATE_BRANCH','CREATE_COMMIT','PUSH_BRANCH','CREATE_PULL_REQUEST','UPDATE_COORDINATION_METADATA','APPROVE_EXACT_HEAD','MARK_READY','ORDINARY_MERGE'],repositoryMembranes:[{repositoryRef:'primary',allowedPaths:EXPECTED_PATHS}],allowedExecutables:['node','git','gh'],allowedEnvironment:[],remoteObservationOwner:'LocalRelay',allowMutationLoop:false,stopConditions:['STOP_ON_UNKNOWN','STOP_ON_PATH_ESCAPE','STOP_ON_AUTH_BLOCK','STOP_ON_TEST_FAILURE']},
 source:{sourceSetRef:'source-set.vexboard.pr393',sourceVersionRef:'source-version.vexboard.pr393.c54c02a4',overlapEvidenceRef:'overlap.vexboard.pr393.none',activeConflictState:'NONE',candidateState:'EXACT',candidateHead:HEAD,candidateTree:TREE,expectedChangedPaths:EXPECTED_PATHS.map(path=>({repositoryRef:'primary',path})),intentionallyUnchangedAuthorizedPaths:[]},
 policy:{maxOuterReturnFiles:10,maxSelectedSourceEntries:20,maxSelectedSourceBytes:500000,maxDiffBytes:5000000,requireRacePreflightBeforeMutation:false,requireLocalValidationBeforePublish:false,requireInputPackageManifest:true,signoffCommit:true,draftPullRequest:true}
};
const stage={repositoryRef:'primary',expectedBase:BASE,expectedHead:HEAD,expectedTree:TREE,branch:BRANCH,pullRequestNumber:393,maxFiles:20,proofCommands:[
 {command:'node',args:['--test',...FOCUSED],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexboard.pr393.focused-contracts',timeoutMs:600000},
 {command:'node',args:['scripts/build-screen-lens.mjs','--verify'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexboard.pr393.catalog-builds-verify',timeoutMs:600000},
 {command:'node',args:['scripts/build-screen-lens.mjs','--subject','vexstream-music','--build','main','--fetch','--check'],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_REPOSITORY',predicateRef:'predicate.vexboard.pr393.vexstream-main-regeneration',timeoutMs:600000},
 {command:'node',args:['--test',...VEXBOARD_TESTS],proofClass:'TEST',candidateEvidence:true,predicateClass:'SOURCE_OWNER_BEHAVIOR',predicateRef:'predicate.vexboard.pr393.full-vexboard-floor',timeoutMs:1800000}
 ],stateRef:'state.vexboard.pr393.source-ready',currentLifecycleState:'SOURCE_READY',currentGoal:'Prove the exact PR393 source-owner candidate only.',remainingGoals:['Fresh Independent Assurance remains separate.','Lived acceptance / Stable promotion remains separate.','Localization feature design remains separate.'],onPass:{lifecycleState:'ASSURANCE_PENDING',nextFunction:'F13.RUN_FRESH_ASSURANCE',nextOwner:'Operations',whyThisIsNext:'Exact-head source-owner proof is complete; fresh Independent Assurance remains unconsumed.'},resultFilename:'RETURN-VEXBOARD-PR393-SOURCE-OWNER.zip'};
const authorityEnvelope={authoritySchemaRef:'vextreme.effect-transaction/v1',semanticAdmissionRef:'github.issue.vexwork.394',transactionRef:'transaction.vexboard.pr393.source-owner.a001',transactionVersion:1,allowedEffectRefs:['effect.vexrelay.execute'],heldEffectRefs:['effect.vexboard.approval','effect.vexboard.ready','effect.vexboard.merge','effect.vexboard.stable-promotion']};
const outerTaskTemplate={schemaVersion:'vextreme.vexlocalbridge-task-manifest/v1',artifactClass:'EXECUTABLE_RELAY',taskRef:'task.vexboard.pr393.vexrelay-carrier',attemptRef:'attempt.vexboard.pr393.vexrelay-carrier.a001',packageRef:'package.vexboard.pr393.vexrelay-carrier.a001',requestRef:'request.vexboard.pr393.vexrelay-carrier.a001',correlationRef:'correlation.vexboard.pr393.vexrelay-carrier.a001',taskStorageKey:'vexboard-pr393-source-owner',attemptStorageKey:'a001',requestingRoleRef:'Coder[VEXBOARD]',requestingInstanceRef:'instance.vexboard.pr393.source-owner.a001',parentOperationsRef:'github.issue.vexwork.394',returnRouteRef:'github.issue.vexwork.394',hostProfileRef:'macos-victor',repositoryExecutionProfileRefOrNull:'profile.repository.vextreme-sdk.macos-v1',repositoryRefOrNull:'VexGPT/VexWork',baseRefOrNull:BASE,headRefOrNull:HEAD,treeRefOrNull:TREE,branchRefOrNull:BRANCH,claimRefOrNull:'claim.vexboard.pr393.source-owner.a001',exactPathRefs:EXPECTED_PATHS,authorityBinding:{authoritySchemaRef:'vextreme.effect-transaction/v1',authorityEnvelopePath:'authority/effect.json',authorityEnvelopeSha256:'0'.repeat(64),semanticAdmissionRef:'stale',transactionRef:'stale',transactionVersion:1,allowedEffectRefs:['stale'],heldEffectRefs:[]},payload:{payloadClass:native.VEXRELAY_ARCHIVE_PAYLOAD_CLASS,payloadRuntime:native.VEXRELAY_ARCHIVE_RUNTIME,payloadPath:'payload/inner-vexrelay.zip',payloadSha256:'0'.repeat(64),typedArgv:[],immutableInputs:[{path:'inputs/vexrelay-binding.json',sha256:'0'.repeat(64)}]},executionStateAtFormation:'TASK_PREPARED',singleUseNonce:'outer-nonce-'+crypto.randomBytes(18).toString('hex'),stopConditions:['stop.on.identity.drift','stop.on.source-owner.failure','stop.on.unknown'],archiveDigestBinding:'FILENAME_SHA256'};

const formed=await formVexRelayTaskArchiveCarrier({recipe:'ExactHeadSourceOwnerProof',seed,stage,outerTaskTemplate,authorityEnvelope,outputDirectory:DOWNLOADS,outputStem:'VEXBOARD-PR393-SOURCE-PROOF-A001',ttlMs:90*60*1000});
const outerZip=formed.outer.finalZip;
const runner=path.join(SDK_ROOT,'lib/vexlocalbridge/templates/RUN-VEX-TASK.command');
const child=spawnSync('/bin/bash',[runner,outerZip],{encoding:'utf8',env:{...process.env,VEXLOCALBRIDGE_AUTHORIZED_EFFECT_REFS_JSON:JSON.stringify(['effect.vexrelay.execute'])}});
process.stdout.write(child.stdout||'');process.stderr.write(child.stderr||'');
if(child.status!==0)throw new Error(`VEXLOCALBRIDGE_RUN_FAILED:${child.status}`);
const matches=(child.stdout||'').match(/"resultZip"\s*:\s*"([^"]+)"/g);
if(!matches?.length)throw new Error('OUTER_RETURN_PATH_NOT_FOUND');
const returnPath=JSON.parse('{'+matches[matches.length-1]+'}').resultZip;
if(!fs.existsSync(returnPath))throw new Error(`OUTER_RETURN_MISSING:${returnPath}`);
const returnSha=shasum(returnPath);

const carrierRoot=fs.mkdtempSync(path.join(os.tmpdir(),'vexboard-pr393-carrier-'));
run('gh',['repo','clone','VexGPT/VexWork',carrierRoot,'--','--branch',CARRIER_BRANCH,'--single-branch']);
const bootstrapManifest=path.join(carrierRoot,CARRIER_PREFIX,'BOOTSTRAP-MANIFEST.json');
if(!fs.existsSync(bootstrapManifest))throw new Error('CARRIER_BOOTSTRAP_MANIFEST_MISSING');
const bm=JSON.parse(fs.readFileSync(bootstrapManifest,'utf8'));
if(bm.candidateHead!==HEAD||bm.candidateTree!==TREE)throw new Error('CARRIER_CANDIDATE_BINDING_DRIFT');
const returnDir=path.join(carrierRoot,CARRIER_PREFIX,'return');fs.mkdirSync(returnDir,{recursive:true});
const target=path.join(returnDir,path.basename(returnPath));
if(fs.existsSync(target))throw new Error('A001_RETURN_ALREADY_PUBLISHED_FAIL_CLOSED');
fs.copyFileSync(returnPath,target);
if(shasum(target)!==returnSha)throw new Error('RETURN_COPY_DIGEST_MISMATCH');
const receipt={schemaVersion:'vexboard.vexrelay-github-custody-receipt/v1',continuity:'[VXG RealForever]',carrierIssue:'github.issue.vexwork.394',pullRequest:'github.pull.vexwork.393',candidateBase:BASE,candidateHead:HEAD,candidateTree:TREE,outerReturnFilename:path.basename(target),outerReturnSha256:returnSha,canonicalReturnBytesChanged:false,transportMeaning:'GitHub custody only; VexRelay remains canonical result owner.',publishedAt:new Date().toISOString()};
fs.writeFileSync(path.join(returnDir,'receipt.json'),JSON.stringify(receipt,null,2)+'\n');
run('git',['config','user.name','VexRelay GitHub Carrier'],{cwd:carrierRoot});
run('git',['config','user.email','vexrelay-carrier@vextreme.invalid'],{cwd:carrierRoot});
run('git',['add',path.relative(carrierRoot,target),path.relative(carrierRoot,path.join(returnDir,'receipt.json'))],{cwd:carrierRoot});
run('git',['commit','-m','[VexRelay][PR393] Publish canonical A001 RETURN custody'],{cwd:carrierRoot});
run('git',['push','origin',`HEAD:${CARRIER_BRANCH}`],{cwd:carrierRoot});
const carrierCommit=run('git',['rev-parse','HEAD'],{cwd:carrierRoot,capture:true}).trim();
console.log('VEXBOARD_PR393_RELAY_DISPOSITION=PASS_TRANSPORT_COMPLETE');
console.log(`VEXBOARD_PR393_CANONICAL_RETURN_SHA256=${returnSha}`);
console.log(`VEXBOARD_PR393_GITHUB_CARRIER_COMMIT=${carrierCommit}`);
console.log(`VEXBOARD_PR393_GITHUB_RETURN_PATH=${CARRIER_PREFIX}/return/${path.basename(target)}`);
